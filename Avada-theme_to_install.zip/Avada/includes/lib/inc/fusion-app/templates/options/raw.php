<?php
/**
 * Underscore.js template.
 *
 * @since 2.0
 * @package fusion-library
 */

?>
<#
	var content = 'undefined' !== typeof param.content ? param.content : '';
#>
<div class="fusion-raw-code">
	{{{ content }}}
</div>
